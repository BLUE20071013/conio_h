#include<graphics.h>
using namespace std;
int main()
{
	system("mode con cols=14 lines=1");
	initgraph(129,129,0);
	PIMAGE pimg2=newimage();
	getimage(pimg2,"logo1.ico");		
	putimage(0,0,pimg2);
	delimage(pimg2);
	Sleep(2500);
	closegraph();
}
