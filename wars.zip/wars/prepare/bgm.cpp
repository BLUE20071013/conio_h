#include<windows.h>
#include<conio.h>
#include<iomanip>
#include<iostream>
#include<ctime>
#include<mmsystem.h>
#pragma comment(lib, "winmm.lib")
int main()
{
	system("mode con cols=14 lines=1");
	SetConsoleTitle("����");
	std::cout<<"����,���Թص�"; 
	while(true)
	{
		PlaySound("bgm.wav",0,SND_FILENAME | SND_ASYNC);
		Sleep(42500);
	}
}
