#include<graphics.h>
using namespace std;
int main()
{
	system("mode con cols=14 lines=1");
	initgraph(641,481,0);
	PIMAGE pimg1=newimage();
	getimage(pimg1,"working group.jpg");		
	putimage(0,0,pimg1);
	delimage(pimg1);
	Sleep(5000);
	closegraph();
}
