#include<graphics.h>
using namespace std;
int main()
{
	system("mode con cols=14 lines=1");
	initgraph(482,123,0);
	PIMAGE pimg=newimage();
	getimage(pimg,"logo3.png");		
	putimage(0,0,pimg);
	delimage(pimg);
	Sleep(5000);
	closegraph();
}
